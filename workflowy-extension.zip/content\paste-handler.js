// Listen for messages from parent window
window.addEventListener('message', async (event) => {
    if (event.data.type === 'CREATE_MIRROR') {
       
            // Find the current node
            let currentNode = document.querySelector('.project.selected');
            if (!currentNode) {
                throw new Error('No selected node found');
            }

            // 1. Click the addChildButton using a simulated click event
            const addChildButton = currentNode.querySelector('.addChildButton');
            if (addChildButton) {
                const clickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                });
                addChildButton.dispatchEvent(clickEvent);
                await new Promise(resolve => setTimeout(resolve, 100)); // Increased delay for node creation
            } else {
                throw new Error('Add child button not found');
            }



            // 4. Type opening parentheses
            document.execCommand('insertText', false, '((');
            await new Promise(resolve => setTimeout(resolve, 30));

            // 5. Type first 10 characters of node text
            const text = event.data.content;
            const typingLength = Math.min(10, text.length);
            for (let i = 0; i < typingLength; i++) {
                document.execCommand('insertText', false, text[i]);
                await new Promise(resolve => setTimeout(resolve, 10));
            }
            await new Promise(resolve => setTimeout(resolve, 30));

            // 6. Press Enter to complete the mirror
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                bubbles: true
            });
            document.dispatchEvent(enterEvent);


    }
});
