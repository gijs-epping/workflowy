Placeholder icons - replace with actual icons before publishing
